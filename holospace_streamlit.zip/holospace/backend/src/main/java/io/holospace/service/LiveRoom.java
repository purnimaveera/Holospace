package io.holospace.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * In-memory, server-authoritative copy of one room while people are connected.
 * State shape: { objects: {id: obj}, notes: {id: note}, strokes: [stroke] }
 */
public class LiveRoom {

    public static final int MAX_OBJECTS = 500;
    public static final int MAX_NOTES = 200;
    public static final int MAX_STROKES = 4000;

    private final String id;
    private final String name;
    private final ObjectNode state;
    private final AtomicBoolean dirty = new AtomicBoolean(false);

    public LiveRoom(String id, String name, ObjectNode state) {
        this.id = id;
        this.name = name;
        this.state = state;
        if (!state.path("objects").isObject()) state.putObject("objects");
        if (!state.path("notes").isObject()) state.putObject("notes");
        if (!state.path("strokes").isArray()) state.putArray("strokes");
    }

    public String getId() { return id; }
    public String getName() { return name; }

    private ObjectNode objects() { return (ObjectNode) state.get("objects"); }
    private ObjectNode notes() { return (ObjectNode) state.get("notes"); }
    private ArrayNode strokes() { return (ArrayNode) state.get("strokes"); }

    public boolean consumeDirty() { return dirty.getAndSet(false); }
    public void markDirty() { dirty.set(true); }

    public synchronized ObjectNode snapshot() { return state.deepCopy(); }
    public synchronized String json() { return state.toString(); }

    /** Applies a persistent operation. Returns true if it changed the room. */
    public synchronized boolean apply(JsonNode op) {
        boolean changed = doApply(op);
        if (changed) dirty.set(true);
        return changed;
    }

    private boolean doApply(JsonNode op) {
        String type = op.path("type").asText("");
        switch (type) {
            case "obj.upsert": {
                JsonNode o = op.path("obj");
                String oid = o.path("id").asText("");
                if (!o.isObject() || oid.isEmpty() || oid.length() > 64) return false;
                if (!objects().has(oid) && objects().size() >= MAX_OBJECTS) return false;
                objects().set(oid, o);
                return true;
            }
            case "obj.remove":
                return objects().remove(op.path("id").asText("")) != null;

            case "note.upsert": {
                JsonNode n = op.path("note");
                String nid = n.path("id").asText("");
                if (!n.isObject() || nid.isEmpty() || nid.length() > 64) return false;
                if (!notes().has(nid) && notes().size() >= MAX_NOTES) return false;
                notes().set(nid, n);
                return true;
            }
            case "note.remove":
                return notes().remove(op.path("id").asText("")) != null;

            case "stroke.add": {
                JsonNode s = op.path("stroke");
                String sid = s.path("id").asText("");
                if (!s.isObject() || sid.isEmpty() || strokes().size() >= MAX_STROKES) return false;
                for (JsonNode e : strokes()) {
                    if (sid.equals(e.path("id").asText())) return false;
                }
                strokes().add(s);
                return true;
            }
            case "stroke.remove": {
                String sid = op.path("id").asText("");
                boolean removed = false;
                for (int i = strokes().size() - 1; i >= 0; i--) {
                    if (sid.equals(strokes().get(i).path("id").asText())) {
                        strokes().remove(i);
                        removed = true;
                    }
                }
                return removed;
            }
            case "stroke.clear":
                if (strokes().size() == 0) return false;
                strokes().removeAll();
                return true;

            default:
                return false;
        }
    }
}
