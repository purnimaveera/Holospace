package io.holospace;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class HoloSpaceApplication {
    public static void main(String[] args) {
        SpringApplication.run(HoloSpaceApplication.class, args);
    }
}
