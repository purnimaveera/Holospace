package io.holospace.ws;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import io.holospace.service.LiveRoom;
import io.holospace.service.RoomService;
import java.net.URI;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.ConcurrentWebSocketSessionDecorator;
import org.springframework.web.socket.handler.TextWebSocketHandler;

/**
 * One endpoint: /ws?room=ROOM_ID&name=DISPLAY_NAME
 * - sends a "welcome" with the full room state on connect
 * - applies persistent operations to the room and relays them to everyone else
 * - relays ephemeral messages (cursors, live strokes) without storing them
 */
@Component
public class HoloSocketHandler extends TextWebSocketHandler {

    private static final String[] COLORS = {
        "#ff7a3d", "#7ff0c8", "#ffd166", "#ff8fb8", "#b9a7ff", "#8fd3ff", "#ffffff", "#c5f06a"
    };
    private static final Set<String> EPHEMERAL = Set.of("cursor", "stroke.live");
    private static final Set<String> PERSISTENT = Set.of(
            "obj.upsert", "obj.remove", "note.upsert", "note.remove",
            "stroke.add", "stroke.remove", "stroke.clear");

    private record Conn(String peerId, String roomId, String name, String color,
                        WebSocketSession out, LiveRoom room) {}

    private final RoomService rooms;
    private final ObjectMapper mapper;
    private final Map<String, Conn> bySession = new ConcurrentHashMap<>();
    private final Map<String, Map<String, Conn>> byRoom = new ConcurrentHashMap<>();

    public HoloSocketHandler(RoomService rooms, ObjectMapper mapper) {
        this.rooms = rooms;
        this.mapper = mapper;
    }

    @Override
    public synchronized void afterConnectionEstablished(WebSocketSession session) throws Exception {
        String roomId = param(session.getUri(), "room");
        String name = cleanName(param(session.getUri(), "name"));
        LiveRoom room = roomId.isBlank() ? null : rooms.open(roomId);
        if (room == null) {
            session.close(new CloseStatus(4404, "room not found"));
            return;
        }

        WebSocketSession out = new ConcurrentWebSocketSessionDecorator(session, 10_000, 1024 * 1024);
        String peerId = "p" + UUID.randomUUID().toString().substring(0, 6);

        // Snapshot + registration happen under the room lock, and so does every operation
        // (see handleTextMessage). An edit is therefore either inside the welcome snapshot
        // or delivered to this peer afterwards, never lost in between.
        synchronized (room) {
            Map<String, Conn> members = byRoom.computeIfAbsent(roomId, k -> new ConcurrentHashMap<>());
            Conn conn = new Conn(peerId, roomId, name, pickColor(members), out, room);
            bySession.put(session.getId(), conn);

            ObjectNode welcome = mapper.createObjectNode();
            welcome.put("type", "welcome");
            welcome.set("you", peerJson(conn));
            ObjectNode r = welcome.putObject("room");
            r.put("id", roomId);
            r.put("name", room.getName());
            welcome.set("state", room.snapshot());
            ArrayNode peers = welcome.putArray("peers");
            for (Conn c : members.values()) {
                peers.add(peerJson(c));
            }
            send(conn, welcome);

            members.put(peerId, conn);

            ObjectNode join = mapper.createObjectNode();
            join.put("type", "peer.join");
            join.set("peer", peerJson(conn));
            broadcast(roomId, peerId, join);
        }
    }

    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) {
        Conn c = bySession.get(session.getId());
        if (c == null) return;

        JsonNode node;
        try {
            node = mapper.readTree(message.getPayload());
        } catch (Exception e) {
            return;
        }
        if (!(node instanceof ObjectNode op)) return;

        String type = op.path("type").asText("");
        boolean persistent = PERSISTENT.contains(type);
        if (!persistent && !EPHEMERAL.contains(type)) {
            return; // ping or unknown
        }
        synchronized (c.room()) {
            if (persistent && !c.room().apply(op)) return;
            op.put("from", c.peerId());
            broadcast(c.roomId(), c.peerId(), op);
        }
    }

    @Override
    public synchronized void afterConnectionClosed(WebSocketSession session, CloseStatus status) {
        Conn c = bySession.remove(session.getId());
        if (c == null) return;
        Map<String, Conn> members = byRoom.get(c.roomId());
        if (members == null) return;
        members.remove(c.peerId());
        if (members.isEmpty()) {
            byRoom.remove(c.roomId());
            rooms.release(c.room());
        } else {
            ObjectNode leave = mapper.createObjectNode();
            leave.put("type", "peer.leave");
            leave.put("id", c.peerId());
            broadcast(c.roomId(), c.peerId(), leave);
        }
    }

    @Override
    public void handleTransportError(WebSocketSession session, Throwable exception) {
        try {
            session.close(CloseStatus.SERVER_ERROR);
        } catch (Exception ignored) {
            // already closed
        }
    }

    private void broadcast(String roomId, String exceptPeerId, JsonNode msg) {
        Map<String, Conn> members = byRoom.get(roomId);
        if (members == null) return;
        String json;
        try {
            json = mapper.writeValueAsString(msg);
        } catch (Exception e) {
            return;
        }
        TextMessage text = new TextMessage(json);
        for (Conn m : members.values()) {
            if (m.peerId().equals(exceptPeerId)) continue;
            try {
                m.out().sendMessage(text);
            } catch (Exception ignored) {
                // slow or closed client: it will be cleaned up on close
            }
        }
    }

    private void send(Conn c, JsonNode msg) {
        try {
            c.out().sendMessage(new TextMessage(mapper.writeValueAsString(msg)));
        } catch (Exception ignored) {
            // client went away
        }
    }

    private ObjectNode peerJson(Conn c) {
        ObjectNode p = mapper.createObjectNode();
        p.put("id", c.peerId());
        p.put("name", c.name());
        p.put("color", c.color());
        return p;
    }

    private static String pickColor(Map<String, Conn> members) {
        for (String color : COLORS) {
            boolean used = false;
            for (Conn m : members.values()) {
                if (m.color().equals(color)) {
                    used = true;
                    break;
                }
            }
            if (!used) return color;
        }
        return COLORS[members.size() % COLORS.length];
    }

    private static String cleanName(String raw) {
        String n = raw == null ? "" : raw.trim();
        if (n.isEmpty()) return "Guest";
        return n.length() > 24 ? n.substring(0, 24) : n;
    }

    private static String param(URI uri, String key) {
        String q = uri == null ? null : uri.getRawQuery();
        if (q == null) return "";
        for (String part : q.split("&")) {
            int i = part.indexOf('=');
            String k = i < 0 ? part : part.substring(0, i);
            if (k.equals(key)) {
                return i < 0 ? "" : URLDecoder.decode(part.substring(i + 1), StandardCharsets.UTF_8);
            }
        }
        return "";
    }
}
