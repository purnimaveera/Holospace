package io.holospace.config;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import java.net.URI;
import javax.sql.DataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

/**
 * Builds the PostgreSQL connection from the DATABASE_URL environment variable.
 * Accepts the formats used by Render / Neon / Supabase / Railway
 * (postgres://user:pass@host:5432/db?sslmode=require) as well as plain jdbc: URLs.
 * With nothing set it uses an embedded H2 file database (./data/holospace), so the app starts
 * with no Docker or PostgreSQL installed. To use a local PostgreSQL instead, set
 * DATABASE_URL=jdbc:postgresql://localhost:5432/holospace (the docker-compose defaults match).
 */
@Configuration
public class DataSourceConfig {

    @Bean
    public DataSource dataSource(Environment env) throws Exception {
        String raw = env.getProperty("DATABASE_URL", "").trim();
        String user = env.getProperty("DB_USER", "holospace");
        String pass = env.getProperty("DB_PASSWORD", "holospace");
        String jdbc;

        if (raw.isEmpty()) {
            jdbc = "jdbc:h2:file:./data/holospace;DB_CLOSE_ON_EXIT=FALSE";
        } else if (raw.startsWith("jdbc:")) {
            jdbc = raw;
        } else {
            URI uri = new URI(raw);
            String info = uri.getUserInfo();
            if (info != null) {
                int i = info.indexOf(':');
                if (i >= 0) {
                    user = info.substring(0, i);
                    pass = info.substring(i + 1);
                } else {
                    user = info;
                }
            }
            int port = uri.getPort() > 0 ? uri.getPort() : 5432;
            String query = uri.getRawQuery() != null ? "?" + uri.getRawQuery() : "";
            jdbc = "jdbc:postgresql://" + uri.getHost() + ":" + port + uri.getPath() + query;
        }

        HikariConfig cfg = new HikariConfig();
        cfg.setJdbcUrl(jdbc);
        cfg.setUsername(user);
        cfg.setPassword(pass);
        cfg.setDriverClassName(jdbc.startsWith("jdbc:h2:") ? "org.h2.Driver" : "org.postgresql.Driver");
        cfg.setMaximumPoolSize(5);
        cfg.setConnectionTimeout(30_000);
        return new HikariDataSource(cfg);
    }
}
