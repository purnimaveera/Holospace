package io.holospace.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import io.holospace.model.Room;
import io.holospace.repo.RoomRepository;
import jakarta.annotation.PreDestroy;
import java.time.Instant;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
public class RoomService {

    private static final Logger log = LoggerFactory.getLogger(RoomService.class);
    private static final String EMPTY_STATE = "{\"objects\":{},\"notes\":{},\"strokes\":[]}";

    private final RoomRepository repo;
    private final ObjectMapper mapper;
    private final Map<String, LiveRoom> live = new ConcurrentHashMap<>();

    public RoomService(RoomRepository repo, ObjectMapper mapper) {
        this.repo = repo;
        this.mapper = mapper;
    }

    public Room create(String rawName) {
        String name = rawName == null ? "" : rawName.trim();
        if (name.isEmpty()) name = "Untitled room";
        if (name.length() > 80) name = name.substring(0, 80);

        Room r = new Room();
        r.setId(UUID.randomUUID().toString().replace("-", "").substring(0, 8));
        r.setName(name);
        r.setStateJson(EMPTY_STATE);
        Instant now = Instant.now();
        r.setCreatedAt(now);
        r.setUpdatedAt(now);
        return repo.save(r);
    }

    public Optional<Room> find(String id) {
        return repo.findById(id);
    }

    /** Loads a room into memory (or returns the already-live copy). Null if it does not exist. */
    public synchronized LiveRoom open(String id) {
        LiveRoom existing = live.get(id);
        if (existing != null) return existing;
        Optional<Room> r = repo.findById(id);
        if (r.isEmpty()) return null;
        LiveRoom lr = new LiveRoom(id, r.get().getName(), parse(r.get().getStateJson()));
        live.put(id, lr);
        return lr;
    }

    /** Called when the last person leaves: save and drop from memory. */
    public synchronized void release(LiveRoom room) {
        flush(room);
        live.remove(room.getId());
    }

    @Scheduled(fixedDelay = 2000)
    public void flushAll() {
        live.values().forEach(this::flush);
    }

    @PreDestroy
    public void shutdown() {
        live.values().forEach(this::flush);
    }

    private void flush(LiveRoom lr) {
        if (!lr.consumeDirty()) return;
        try {
            repo.findById(lr.getId()).ifPresent(r -> {
                r.setStateJson(lr.json());
                r.setUpdatedAt(Instant.now());
                repo.save(r);
            });
        } catch (Exception e) {
            lr.markDirty();
            log.warn("Could not save room {}: {}", lr.getId(), e.getMessage());
        }
    }

    private ObjectNode parse(String json) {
        try {
            JsonNode n = mapper.readTree(json == null ? "{}" : json);
            if (n instanceof ObjectNode o) return o;
        } catch (Exception ignored) {
            // fall through to empty state
        }
        return mapper.createObjectNode();
    }
}
