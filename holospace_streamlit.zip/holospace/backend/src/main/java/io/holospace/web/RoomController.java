package io.holospace.web;

import io.holospace.model.Room;
import io.holospace.service.RoomService;
import java.time.Instant;
import java.util.Map;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RoomController {

    public record CreateRoomRequest(String name) {}

    public record RoomDto(String id, String name, Instant updatedAt) {}

    private final RoomService rooms;

    public RoomController(RoomService rooms) {
        this.rooms = rooms;
    }

    @GetMapping("/")
    public String root() {
        return "HoloSpace API is running.";
    }

    @GetMapping("/api/health")
    public Map<String, String> health() {
        return Map.of("status", "ok");
    }

    @PostMapping("/api/rooms")
    public RoomDto create(@RequestBody(required = false) CreateRoomRequest body) {
        Room r = rooms.create(body == null ? null : body.name());
        return new RoomDto(r.getId(), r.getName(), r.getUpdatedAt());
    }

    @GetMapping("/api/rooms/{id}")
    public ResponseEntity<RoomDto> get(@PathVariable String id) {
        return rooms.find(id)
                .map(r -> ResponseEntity.ok(new RoomDto(r.getId(), r.getName(), r.getUpdatedAt())))
                .orElseGet(() -> ResponseEntity.notFound().build());
    }
}
