"""Streamlit launcher for HoloSpace.

Serves the built React frontend (frontend/dist) from Streamlit's static folder and
embeds it full-screen. The Spring Boot backend still runs separately (e.g. Render),
because Streamlit cannot host a Java/WebSocket server.

Backend URL: set VITE_API_URL (env var or Streamlit secret). Leave it empty for demo
mode (rooms sync between tabs of the same browser only).
"""
import os
import shutil
import subprocess
from pathlib import Path

import streamlit as st
import streamlit.components.v1 as components

ROOT = Path(__file__).parent
FRONTEND = ROOT / "frontend"
DIST = FRONTEND / "dist"
TARGET = ROOT / "static" / "holospace"

st.set_page_config(page_title="HoloSpace", page_icon="🧊", layout="wide", initial_sidebar_state="collapsed")


def api_url() -> str:
    try:
        if "VITE_API_URL" in st.secrets:
            return str(st.secrets["VITE_API_URL"]).strip()
    except Exception:
        pass
    return os.environ.get("VITE_API_URL", "").strip()


@st.cache_resource(show_spinner="Preparing HoloSpace (first start only)...")
def prepare(api: str) -> str:
    """Make sure static/holospace contains the built frontend. Returns an error text or ''."""
    if not (DIST / "index.html").exists():
        if shutil.which("npm") is None:
            return "frontend/dist is missing and npm is not available. Run `npm install && npm run build` in frontend/ and commit the result."
        env = {**os.environ, "VITE_API_URL": api}
        for cmd in (["npm", "install", "--no-audit", "--no-fund"], ["npm", "run", "build"]):
            r = subprocess.run(cmd, cwd=FRONTEND, env=env, capture_output=True, text=True)
            if r.returncode != 0:
                return (r.stdout + r.stderr)[-2000:]
    if TARGET.exists():
        shutil.rmtree(TARGET)
    shutil.copytree(DIST, TARGET)
    return ""


st.markdown(
    """
    <style>
      header, footer, #MainMenu {visibility: hidden; height: 0;}
      .block-container {padding: 0 !important; max-width: 100% !important;}
      iframe {border: 0;}
    </style>
    """,
    unsafe_allow_html=True,
)

error = prepare(api_url())
if error:
    st.error("Could not prepare the frontend.")
    st.code(error)
else:
    # Optional deep link: ?room=ID opens that room directly.
    room = st.query_params.get("room", "")
    hash_part = f"#/room/{room}" if room else ""
    components.iframe(f"./app/static/holospace/index.html{hash_part}", height=900, scrolling=False)
