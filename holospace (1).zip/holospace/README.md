# HoloSpace

A shared browser workspace: a 3D stage (Three.js), a whiteboard with sticky notes, live cursors,
and rooms that are saved to PostgreSQL so a team can come back and continue.

```
holospace/
  backend/    Spring Boot 3 (Java 17) + WebSockets + PostgreSQL
  frontend/   React + Vite + Three.js
  render.yaml One-click backend + database on Render
```

## Important: what runs where

Vercel hosts the **frontend** (static React app). Vercel cannot run the Spring Boot server because it
does not support long-lived WebSocket connections. The backend goes on Render (free, supports WebSockets).
Total: two deploys, both a few clicks.

## Option A: Vercel only (demo mode, 2 minutes)

1. Push this folder to GitHub.
2. Vercel > Add New Project > import the repo.
3. Set **Root Directory** to `frontend`. Leave everything else as detected (Vite).
4. Deploy. Do **not** set `VITE_API_URL`.

You get a working link. Rooms sync between tabs of the same browser only (good for trying it out).

## Option B: Full real-time version (Vercel + Render)

### 1) Backend + database on Render
1. Push this folder to GitHub.
2. Render > New > **Blueprint** > select the repo. It reads `render.yaml` and creates the API and the database.
3. Wait for the deploy, then open `https://YOUR-API.onrender.com/api/health`. It should show `{"status":"ok"}`.

(Free Render services sleep when idle, so the first request after a quiet spell can take ~50 seconds.
Free Render databases expire after 30 days; use the free tier of Neon or Supabase for something longer-lived:
paste its connection string into `DATABASE_URL`.)

### 2) Frontend on Vercel
1. Vercel > Add New Project > import the same repo, **Root Directory = `frontend`**.
2. Environment Variables: `VITE_API_URL` = `https://YOUR-API.onrender.com` (no trailing slash).
3. Deploy, open the link, create a room, send the invite link to a teammate.

If you change `VITE_API_URL` later, redeploy (Vite bakes it in at build time).

### 3) Optional: lock down CORS
In Render, set `CORS_ORIGINS` to your Vercel URL, e.g. `https://holospace.vercel.app`.

## Run locally

You need **Java 17+**, **Maven** and **Node 18+**. Docker and PostgreSQL are optional.

```bash
# 1) backend (terminal 1)
cd backend
mvn spring-boot:run            # http://localhost:8080  (check http://localhost:8080/api/health)

# 2) frontend (terminal 2)
cd frontend
npm install
npm run dev                    # http://localhost:5173
```

Open the app in two browser windows to watch changes sync.

- With no `DATABASE_URL` the backend stores rooms in an embedded H2 file database at `backend/data/`, so nothing
  else needs installing. Delete that folder to reset all rooms.
- To use PostgreSQL locally instead: `cd backend && docker compose up -d`, then start the backend with
  `DATABASE_URL=jdbc:postgresql://localhost:5432/holospace` (the docker-compose user and password are the defaults).
  PowerShell: `$env:DATABASE_URL="jdbc:postgresql://localhost:5432/holospace"; mvn spring-boot:run`
- `npm run dev` reads `frontend/.env.development`, which already points at `http://localhost:8080`. No `.env.local`
  is needed. To try demo mode (no backend) set `VITE_API_URL=` (empty) in a new `frontend/.env.local`.

### Troubleshooting

- **"Connecting…" never finishes / banner says demo mode:** the backend is not running, or `VITE_API_URL` is empty.
  Restart `npm run dev` after changing any `.env` file.
- **Port 8080 already in use:** `PORT=8081 mvn spring-boot:run` (PowerShell: `$env:PORT=8081`) and set
  `VITE_API_URL=http://localhost:8081` in `frontend/.env.local`.
- **Blank 3D stage:** the browser has WebGL disabled. Enable hardware acceleration, or use Chrome/Edge/Firefox.

## How it works

- `POST /api/rooms` creates a room; `GET /api/rooms/{id}` checks it exists.
- Clients open `wss://API/ws?room=ID&name=NAME`. The server sends the full room state, then relays operations
  (`obj.upsert`, `note.upsert`, `stroke.add`, ...) to everyone else. Cursors and in-progress strokes are
  relayed but not stored.
- The server keeps each active room in memory and saves it to PostgreSQL every 2 seconds and when the last
  person leaves. Reopening the link restores objects, notes and drawings.
- Conflicts are last-write-wins per object, which is fine for small teams.

## Controls

- 3D: click an object to select, drag it to move, drag empty space to orbit, scroll to zoom, Delete removes it.
- Whiteboard: Pen draws; Sticky note then click the board adds a comment; drag a note by its top bar.
